from django.shortcuts import render,get_object_or_404,redirect
from django.http import HttpResponse
from django.utils import timezone
from .models import Question
from .forms import QuestionForm,AnswerForm
from django.core.paginator import Paginator

# Create your views here.
def index(request):
    """
     목록 출력
    """
    page = request.GET.get('page','1')
    question_list = Question.objects.order_by('-create_date')
    
    paginator = Paginator(question_list,10)
    page_obj = paginator.get_page(page)
    
    context =  {'question_list':page_obj}
    return render(request, 'review/question_list.html',context)

def detail(request,question_id):
    """
     내용 출력 
    """
    question=get_object_or_404(Question,pk=question_id)
    context = {'question':question}
    return render(request,'review/question_detail.html',context)

def answer_create(request,question_id):
    """
    답변 등록

    """

    question = get_object_or_404(Question,pk=question_id)
    question.answer_set.create(content=request.POST.get('content'),
                                create_date=timezone.now())   
    return redirect('review:detail',question_id=question.id) 


def question_create(request):
    """
     질문 등록
    """
    if request.method =='POST':
        form = QuestionForm(request.POST)
        if form.is_valid(): # form이 유효한지 검증
            question = form.save(commit=False)  # form에 create_date이 없으므로 여기서 저장하면 에러발생!
            question.create_date = timezone.now()  # create_date를 넣어주고 저장
            question.save()
            return redirect('review:index')  # index는 초기화면이다
    else:
        form = QuestionForm()            # method가 GET인 경우
    context = {'form':form}
    return render(request,'review/question_form.html',context)


def answer_create(request,question_id):
    '''
     답변 등록
    '''
    question = get_object_or_404(Question,pk=question_id)
    if request.method == "POST":
        form = AnswerForm(request.POST)
        if form.is_valid():
            answer = form.save(commit=False)
            answer.create_date = timezone.now()
            answer.question = question
            answer.save()
            return redirect('review:detail', question_id = question_id)
    else:
        form = AnswerForm()
    context = {'question':question, 'form':form}
    return render(request, 'review/question_detail.html', context)