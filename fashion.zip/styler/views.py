from django.shortcuts import render,get_object_or_404,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.utils import timezone

from django.urls import reverse
from django .template import loader

#from .models import Menu
#from .forms import QuestionForm,AnswerForm
#from django.core.paginator import Paginator

# Create your views here.
def index(request):

    return render (request,'styler/main.html')


def menu1(request):
    return render(request, 'styler/menu1.html')





def menu2(request):

    return render (request,'styler/menu2.html')

def menu3(request):

    return render (request,'styler/menu3.html')    

def menu4(request):

    return render (request,'styler/menu4.html')        

def menu5(request):

    return render (request,'styler/menu5.html')        




def result(request):

    return render (request,'styler/result.html')




