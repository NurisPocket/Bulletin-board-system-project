from django.apps import AppConfig


class StylerConfig(AppConfig):
    name = 'styler'
