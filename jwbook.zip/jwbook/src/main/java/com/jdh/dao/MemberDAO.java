package com.jdh.dao;



import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import com.jdh.dto.MemberDTO;

public class MemberDAO {

	Connection conn = null;
	PreparedStatement pstmt;
	ResultSet rs = null;
	
	final String JDBC_DRIVER = "org.h2.Driver";  //org.h2.Driver
	final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jwbookdb";
	
	
	public Connection open() {
		Connection conn = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(JDBC_URL,"jwbook","1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	public static MemberDAO instance = null;

 



	private MemberDAO() {

	}

 


	public static MemberDAO getInstance() {

		if(instance == null) {

			instance = new MemberDAO();

		}


		return instance;

	}

 

	public int userCheck(String userid, String pwd) {



		int result=-1;

 

		String query="SELECT pwd FROM member_tbl WHERE userid=?";


		try {

			Connection conn = open();

			pstmt = conn.prepareStatement(query);

			pstmt.setString(1, userid);

			rs = pstmt.executeQuery();

 

			if(rs.next()) {

				if(rs.getString("pwd") != null && rs.getString("pwd").equals(pwd)) {


					result=1;

				} else {


					result=0;

				}

			} else {


				result=-1;

			}

 

		} catch(SQLException e) {

			e.printStackTrace();

		} finally {

			try {

				if(rs != null) {rs.close();}

				if(pstmt != null) {pstmt.close();}

				if(conn != null) {conn.close();}

			} catch(SQLException e) {

				e.printStackTrace();

			}

		}

 

		return result;

	}

 


	// 아이디 회원 정보 

	public MemberDTO getMember(String userid) {

		MemberDTO dto=null;

		String query="SELECT * FROM member_tbl WHERE userid=?";


		try {

			Connection conn = open();

			pstmt = conn.prepareStatement(query);

			pstmt.setString(1, userid);

			rs = pstmt.executeQuery();

 

			if(rs.next()) {

				dto = new MemberDTO();

				dto.setName(rs.getString("name"));

				dto.setUserid(rs.getString("userid"));

				dto.setPwd(rs.getString("pwd"));

				dto.setEmail(rs.getString("email"));

				dto.setPhone(rs.getString("phone"));

				dto.setGender(rs.getInt("gender"));

 

			}

 

		} catch(SQLException e) {

			e.printStackTrace();

		} finally {

			try {

				if(rs!=null) {rs.close();}

				if(pstmt!=null) {pstmt.close();}

				if(conn!=null) {conn.close();}

			} catch(SQLException e){

				e.printStackTrace();

			}

		}

		return dto;

	}
 

 
	// 아이디 중복 확인 

	public int confirmID(String userid) {

	

		int result=-1;

 

		String query="SELECT userid FROM member_tbl WHERE userid=?";

		try {

			Connection conn = open();

			pstmt = conn.prepareStatement(query);

			pstmt.setString(1, userid);

			rs = pstmt.executeQuery();

 

			if(rs.next()) {

				result = 1;

			} else {

				result = -1;

			}

 

		} catch(SQLException e) {

			e.printStackTrace();

		} finally {

			try {

				if(rs!=null) {rs.close();}

				if(pstmt!=null) {pstmt.close();}

				if(conn!=null) {conn.close();}

			} catch(SQLException e) {

				e.printStackTrace();

			}

		}

 

		return result;

	}

 


 
	// 회원 가입 

	public int insertMember(MemberDTO dto) {

		int result=-1;

 

		String query="INSERT INTO member_tbl values (member_seq.nextval,?,?,?,?,?,?)";


		try {

			Connection conn = open();

			pstmt = conn.prepareStatement(query);

			pstmt.setString(1, dto.getName());

			pstmt.setString(2, dto.getUserid());

			pstmt.setString(3, dto.getPwd());

			pstmt.setString(4, dto.getEmail());

			pstmt.setString(5, dto.getPhone());

			pstmt.setInt(6, dto.getGender());

 

			result = pstmt.executeUpdate();

 

 

		}catch(SQLException e) {

			e.printStackTrace();

		} finally {

			try {

				if(pstmt!=null) {pstmt.close();}

				if(conn!=null) {conn.close();}

			}catch(SQLException e) {

				e.printStackTrace();
			}
			
		}

		return result;

	}

 

	// 회원 정보 수정 

	public int updateMember(MemberDTO dto) {

		int result=-1;

 

		String query="UPDATE member_tbl SET pwd=?,email=?,phone=?,gender=? WHERE userid=?";


		try {

			Connection conn = open();

			pstmt = conn.prepareStatement(query);

			pstmt.setString(1,dto.getPwd());

			pstmt.setString(2,dto.getEmail());

			pstmt.setString(3,dto.getPhone());

			pstmt.setInt(4,dto.getGender());

			pstmt.setString(5,dto.getUserid());

 

			result = pstmt.executeUpdate();

 

		}catch(SQLException e) {

			e.printStackTrace();

		} finally {

			try {

				if(pstmt!=null) {pstmt.close();}

				if(conn!=null) {conn.close();}

			}catch(SQLException e) {

				e.printStackTrace();

			}

		}

		return result;

	}

	
	}